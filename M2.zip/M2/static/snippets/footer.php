<footer>
    <hr>
    <div class="container-fluid bg-primary justify-content-center align-items-end">
        <div class="row align-items-end p-2">
            <div class=" col-2">
                <p>(c) DBWT <?php echo date('Y')?></p>
            </div>
            <div class="col-2 text-center border-right border-white">
                <a href="Login.html" class="text-white">Login</a>
            </div>
            <div class="col-2 text-center border-right border-white">
                <a href="Registrieren.html" class="text-white">Registrieren</a>
            </div>
            <div class="col-2 text-center border-right border-white">
                <a href="Zutatenliste.php" class="text-white">Zutatenliste</a>
            </div>
            <div class="col-2 text-center text-justify">
                <a href="Impressum.html" class="text-white">Impressum</a>
            </div>
        </div>
    </div>
</footer>
